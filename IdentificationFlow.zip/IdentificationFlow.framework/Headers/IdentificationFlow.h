//
//  IdentificationFlow.h
//  IdentificationFlow
//
//  Created by Florin Balcescu on 02/09/2018.
//  Copyright © 2018 Florin Balcescu. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for IdentificationFlow.
FOUNDATION_EXPORT double IdentificationFlowVersionNumber;

//! Project version string for IdentificationFlow.
FOUNDATION_EXPORT const unsigned char IdentificationFlowVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <IdentificationFlow/PublicHeader.h>
//#import "AbbyyRtrSDK/AbbyyRtrSDK.h"

